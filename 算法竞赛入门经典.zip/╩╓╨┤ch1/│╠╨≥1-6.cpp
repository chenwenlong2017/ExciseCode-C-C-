#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	if(n%10)
		printf("%d%d%d",n%10,n/10%10,n/100); 
	else
		printf("%d%d",n/10%10,n/100);
	return 0;
}
//��λ����ת  
