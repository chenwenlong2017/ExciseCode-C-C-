#include<stdio.h>
#include<math.h>
#define Pi 3.1415926
int main()
{
	double r,h,s1,s2;
	scanf("%lf%lf",&r,&h);
	s1=Pi*r*r;
	s2=2*Pi*r*h; 
	printf("%lf",2*s1+s2);
	return 0;
}
//math�����ṩPi���� 
