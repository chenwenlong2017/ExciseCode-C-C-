#include<stdio.h>
#include<math.h>
int main()
{
	double item=1.0,sum=0.0,flag=1.0,n=1.0,m=1.0;
	while(fabs(item)>0.000001){
		item=flag/m;
		n=n+1;
		flag=-flag;
		m=flag/(2*n-1);
		sum=sum+item;
		if(n>100)
			break;
		//printf("%lf",item);
	}
	printf("%lf",sum);
	return 0;
	/*double sum=0;
	for(int i=0;;i++){
		double term=1.0/(i*2+1);
		if(i%2==0)	sum+=term;
		else sum-=term;
		if(term<1e-6) break;
	}
	printf("%.6f",sum);
	return 0;*/
}

