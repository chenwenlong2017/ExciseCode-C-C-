#include<stdio.h>
int main()
{
	int b,s,g;
	for(int i=100;i<=999;i++){
		b=i/100;
		s=i/10%10;
		g=i%10;
		if(i==b*b*b+s*s*s+g*g*g){
			printf("%d\n",i);
		}
	} 
	return 0;
}
//ˮ�ɻ��� 
